import sys, traceback, os
out = []
try:
    import torch
    out.append("torch version: " + str(torch.__version__))
except Exception as e:
    out.append("IMPORT TORCH FAIL: " + repr(e))
    out.append(traceback.format_exc())
try:
    import torchvision
    out.append("torchvision: " + str(torchvision.__version__))
except Exception as e:
    out.append("IMPORT TV FAIL: " + repr(e))
try:
    out.append("cuda available: " + str(torch.cuda.is_available()))
    if torch.cuda.is_available():
        out.append("device: " + torch.cuda.get_device_name(0))
        out.append("capability: " + str(torch.cuda.get_device_capability(0)))
except Exception as e:
    out.append("CUDA CHECK FAIL: " + repr(e))
    out.append(traceback.format_exc())
open(os.path.join(os.path.dirname(os.path.abspath(__file__)), '_env_check.txt'),"w",encoding="utf-8").write("\n".join(out))
