import os, time
import numpy as np
import torch, torch.nn as nn, torch.optim as optim
from torchvision import datasets, transforms
from torch.utils.data import DataLoader, random_split
import matplotlib.pyplot as plt

os.environ['KMP_DUPLICATE_LIB_OK'] = 'True'
ROOT = os.path.dirname(os.path.abspath(__file__))
DATAROOT = os.path.join(ROOT, 'data')
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
torch.manual_seed(42); np.random.seed(42)

def load(name, bs=128, val=0.1):
    if name == 'fashion':
        tf = transforms.Compose([transforms.ToTensor(), transforms.Normalize((0.2860,),(0.3530,))])
        tr = datasets.FashionMNIST(DATAROOT, train=True, download=True, transform=tf)
        te = datasets.FashionMNIST(DATAROOT, train=False, download=True, transform=tf)
    else:
        tf = transforms.Compose([transforms.ToTensor(), transforms.Normalize((0.4914,0.4822,0.4465),(0.2470,0.2435,0.2616))])
        tr = datasets.CIFAR10(DATAROOT, train=True, download=True, transform=tf)
        te = datasets.CIFAR10(DATAROOT, train=False, download=True, transform=tf)
    n = len(tr); vs = int(val*n); ts = n-vs
    trs, vas = random_split(tr, [ts, vs], generator=torch.Generator().manual_seed(42))
    return (DataLoader(trs,bs,shuffle=True), DataLoader(vas,bs), DataLoader(te,bs))

class MLP(nn.Module):
    def __init__(self, ins, hn, nl, act):
        super().__init__()
        self.ins = ins; self.actn = act
        self.inp = nn.Linear(ins, hn)
        self.hds = nn.ModuleList([nn.Linear(hn,hn) for _ in range(nl)])
        self.out = nn.Linear(hn, 10)
        self._w()
    def _w(self):
        relu = self.actn == 'relu'
        for L in [self.inp]+list(self.hds)+[self.out]:
            if relu: nn.init.kaiming_normal_(L.weight, nonlinearity='relu')
            else: nn.init.xavier_normal_(L.weight)
            nn.init.zeros_(L.bias)
    def act(self, x):
        return torch.relu(x) if self.actn=='relu' else torch.sigmoid(x)
    def forward(self, x):
        x = x.view(-1, self.ins)
        x = self.act(self.inp(x))
        for L in self.hds: x = self.act(L(x))
        return self.out(x)

@torch.no_grad()
def ev(m, ld, crit):
    m.eval(); ls=0.; c=0; t=0
    for d,y in ld:
        d,y = d.to(device), y.to(device)
        o = m(d); ls += crit(o,y).item()
        c += o.max(1)[1].eq(y).sum().item(); t += y.size(0)
    return ls/len(ld), 100.*c/t

def train(m, trl, vll, tel, epochs, lr, title, savefig, es=False, patience=5):
    crit = nn.CrossEntropyLoss()
    opt = optim.SGD(m.parameters(), lr=lr, momentum=0.9)
    sch = optim.lr_scheduler.StepLR(opt, 15, 0.5)
    H = {'tl':[], 'ta':[], 'vl':[], 'va':[], 'tea':[]}
    best_vl = float('inf'); best_ep = 1; bad = 0; stop = epochs
    print(f'\n== {title}  device={device}  params={sum(p.numel() for p in m.parameters()):,} ==')
    print(f"{'Ep':>3}|{'tLoss':>7}|{'tAcc':>6}|{'vLoss':>7}|{'vAcc':>6}|{'teAcc':>6}|{'秒':>6}")
    for ep in range(1, epochs+1):
        t0=time.time(); m.train(); ls=0.; c=0; t=0
        for d,y in trl:
            d,y = d.to(device), y.to(device)
            o=m(d); loss=crit(o,y)
            opt.zero_grad(); loss.backward(); opt.step()
            ls += loss.item(); c += o.max(1)[1].eq(y).sum().item(); t += y.size(0)
        ta = 100.*c/t; tl = ls/len(trl)
        vloss, vacc = ev(m, vll, crit); _, tea = ev(m, tel, crit)
        sch.step()
        H['tl'].append(tl); H['ta'].append(ta); H['vl'].append(vloss)
        H['va'].append(vacc); H['tea'].append(tea)
        print(f"{ep:>3}|{tl:>7.4f}|{ta:>6.2f}|{vloss:>7.4f}|{vacc:>6.2f}|{tea:>6.2f}|{time.time()-t0:>6.1f}")
        if vloss < best_vl: best_vl=vloss; best_ep=ep; bad=0
        else:
            bad += 1
            if es and bad >= patience:
                stop = ep; print(f'>> Early Stop: 验证损失连续{patience}轮不改善，第{ep}轮停'); break
    # 汇总
    fi = len(H['tl'])-1
    print('\n---- 汇总 ----')
    print(f"训练轮数(实际): {stop}")
    print(f"训练acc(末轮): {H['ta'][-1]:.2f}%")
    print(f"测试acc(末轮): {H['tea'][-1]:.2f}%")
    print(f"最佳epoch(按验证损失最低): {best_ep}  对应验证损失={best_vl:.4f}  对应测试acc={H['tea'][best_ep-1]:.2f}%")
    print(f"泛化间隙(训练-测试,末轮): {H['ta'][-1]-H['tea'][-1]:.2f}%")
    print(f"模型参数总量: {sum(p.numel() for p in m.parameters()):,}")
    # 画图
    xs = range(1, len(H['tl'])+1)
    fig,(a1,a2)=plt.subplots(1,2,figsize=(11,4.5))
    a1.plot(xs,H['tl'],'-',label='train loss'); a1.plot(xs,H['vl'],'-',label='val loss')
    a1.axvline(best_ep,ls='--',color='r',alpha=.5); a1.set_title('Loss'); a1.legend(); a1.grid(alpha=.3)
    a2.plot(xs,H['ta'],'-',label='train acc'); a2.plot(xs,H['va'],'-',label='val acc')
    a2.plot(xs,H['tea'],'-',label='test acc'); a2.set_title('Accuracy(%)'); a2.legend(); a2.grid(alpha=.3)
    fig.suptitle(title); fig.tight_layout(); fig.savefig(savefig, dpi=110); plt.close()
    print(f"曲线已存: {savefig}")
    return {'best_ep':best_ep,'best_vl':best_vl,'best_teacc':H['tea'][best_ep-1],
            'train_acc':H['ta'][-1],'test_acc':H['tea'][-1],'gap':H['ta'][-1]-H['tea'][-1],
            'params':sum(p.numel() for p in m.parameters()),'epochs_run':stop}
