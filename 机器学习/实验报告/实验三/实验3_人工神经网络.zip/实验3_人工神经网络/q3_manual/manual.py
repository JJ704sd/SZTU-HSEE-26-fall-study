import torch
import torch.nn.functional as F
import numpy as np
import pandas as pd

# 设置随机种子
torch.manual_seed(42)
np.random.seed(42)


# 1. 手动编程实现2层神经网络（BP神经网络）
class BPNeuralNetwork:
    def __init__(self):
        self.input_n = 0
        self.hidden_n = 0
        self.output_n = 0
        self.input_weights = None
        self.output_weights = None

    def setup(self, ni, nh, no):
        self.input_n = ni + 1  # +1 for bias
        self.hidden_n = nh
        self.output_n = no

        # 初始化权重
        self.input_weights = torch.FloatTensor(self.input_n, nh).uniform_(-0.2, 0.2)
        self.output_weights = torch.FloatTensor(nh, no).uniform_(-2.0, 2.0)

    def sigmoid(self, x):
        return 1.0 / (1.0 + torch.exp(-x))

    def sigmoid_derivative(self, x):
        return x * (1 - x)

    def predict(self, inputs, return_intermediate=False):
        batch_size = len(inputs)
        # 添加偏置项到所有样本
        ones = torch.ones(batch_size, 1)
        input_cells_batch = torch.cat([inputs, ones], dim=1)

        hidden_total = torch.matmul(input_cells_batch, self.input_weights)
        hidden_cells = self.sigmoid(hidden_total)
        output_total = torch.matmul(hidden_cells, self.output_weights)
        output_cells = self.sigmoid(output_total)

        if return_intermediate:
            return output_cells, hidden_cells, input_cells_batch
        else:
            return output_cells

    def back_propagate(self, cases, labels, learn_rate):
        # 调用predict函数获取所有中间结果
        output_cells, hidden_cells, input_cells_batch = self.predict(cases, return_intermediate=True)
        batch_size = len(cases)

        # 批量计算误差
        output_error = output_cells - labels
        output_deltas = output_error * self.sigmoid_derivative(output_cells)

        hidden_error = torch.matmul(output_deltas, self.output_weights.t())
        hidden_deltas = hidden_error * self.sigmoid_derivative(hidden_cells)

        # 批量更新权重
        input_weights_grad = torch.matmul(input_cells_batch.t(), hidden_deltas)
        output_weights_grad = torch.matmul(hidden_cells.t(), output_deltas)

        self.input_weights -= learn_rate * input_weights_grad / batch_size
        self.output_weights -= learn_rate * output_weights_grad / batch_size

        # 计算平均误差
        error = 0.5 * torch.sum((output_cells - labels) ** 2) / batch_size
        return error.item()

    def train(self, cases, labels, limit=100, learn_rate=0.05):
        """训练函数"""
        for epoch in range(limit):
            error = self.back_propagate(cases, labels, learn_rate)

            if epoch % 10 == 0:  # 每10个epoch输出一次
                print(f'Epoch {epoch}, Error: {error:.6f}')


def load_data():
    df = pd.read_csv('mnist_train_100.csv', header=None)
    X_train_torch = torch.from_numpy(df.iloc[:, 1:].values).float()
    X_train_torch = (X_train_torch / 255.0 * 0.99) + 0.01
    y_train_torch = torch.from_numpy(df.iloc[:, 0].values).long()
    y_train_onehot = F.one_hot(y_train_torch, num_classes=10).float()

    df = pd.read_csv('mnist_test_10.csv', header=None)
    X_test_torch = torch.from_numpy(df.iloc[:, 1:].values).float()
    X_test_torch = (X_test_torch / 255.0 * 0.99) + 0.01
    y_test_torch = torch.from_numpy(df.iloc[:, 0].values).long()
    y_test_onehot = F.one_hot(y_test_torch, num_classes=10).float()

    return X_train_torch, y_train_onehot, X_test_torch, y_test_onehot


def main():
    nn = BPNeuralNetwork()
    X_train, y_train, X_test, y_test = load_data()

    nn.setup(784, 200, 10)
    print("开始训练...")
    nn.train(X_train, y_train, limit=500, learn_rate=0.1)

    print("测试结果:")
    y_test_pred = nn.predict(X_test)
    y_test_pred_labels = torch.argmax(y_test_pred, dim=1)
    y_test_true_labels = torch.argmax(y_test, dim=1)

    correct = (y_test_pred_labels == y_test_true_labels).sum().item()
    total = len(y_test_true_labels)
    accuracy = correct / total

    print(f"预测标签: {y_test_pred_labels}")
    print(f"真实标签: {y_test_true_labels}")
    print(f"准确率: {accuracy:.2f} ({correct}/{total})")


if __name__ == "__main__":
    main()