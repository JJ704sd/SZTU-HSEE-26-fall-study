import os, time
import numpy as np, pandas as pd
import torch, torch.nn as nn, torch.nn.functional as F, torch.optim as optim
import matplotlib.pyplot as plt

os.environ['KMP_DUPLICATE_LIB_OK'] = 'True'
torch.manual_seed(42); np.random.seed(42)
D = os.path.dirname(os.path.abspath(__file__))

def load():
    df = pd.read_csv(os.path.join(D,'mnist_train_100.csv'), header=None)
    Xtr = torch.from_numpy(df.iloc[:,1:].values).float()/255.0*0.99+0.01
    ytr = F.one_hot(torch.from_numpy(df.iloc[:,0].values).long(),10).float()
    df = pd.read_csv(os.path.join(D,'mnist_test_10.csv'), header=None)
    Xte = torch.from_numpy(df.iloc[:,1:].values).float()/255.0*0.99+0.01
    yte = F.one_hot(torch.from_numpy(df.iloc[:,0].values).long(),10).float()
    return Xtr,ytr,Xte,yte

class AutoNet(nn.Module):
    def __init__(self):
        super().__init__()
        self.f1 = nn.Linear(784,200)
        self.f2 = nn.Linear(200,10)
    def forward(self,x):
        return torch.sigmoid(self.f2(torch.sigmoid(self.f1(x))))

Xtr,ytr,Xte,yte = load()
net = AutoNet()
print(f'参数量: {sum(p.numel() for p in net.parameters()):,}')
crit = nn.MSELoss()
opt = optim.SGD(net.parameters(), lr=0.1)

hist=[]; print(f"{'ep':>4}|{'loss':>10}|{'train_acc':>9}")
for ep in range(500):
    net.train()
    out = net(Xtr)
    loss = crit(out, ytr)
    opt.zero_grad(); loss.backward(); opt.step()
    if ep % 10 == 0:
        ta = (out.max(1)[1]==ytr.max(1)[1]).float().mean().item()*100
        hist.append(loss.item()); print(f'{ep:>4}|{loss.item():>10.6f}|{ta:>9.2f}')

# 测试
net.eval()
with torch.no_grad():
    te = net(Xte)
    tp = te.max(1)[1]; tt = yte.max(1)[1]
    acc = (tp==tt).float().mean().item()*100
    print('\n预测:', tp.tolist()); print('真实:', tt.tolist())
    print(f'测试准确率: {acc:.1f}%  ({(tp==tt).sum().item()}/{len(tt)})')

plt.figure(figsize=(6,4))
plt.plot(range(0,500,10), hist, '-o', ms=3)
plt.xlabel('epoch'); plt.ylabel('MSE loss'); plt.title('Q3 AutoGrad loss curve')
plt.grid(alpha=.3); plt.tight_layout()
p = os.path.join(D,'fig_q3.png'); plt.savefig(p,dpi=110); print('曲线:', p)
