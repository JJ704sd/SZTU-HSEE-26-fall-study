import torch
import torch.nn as nn
import torch.optim as optim
from torchvision import datasets, transforms
from torch.utils.data import DataLoader, random_split
import matplotlib.pyplot as plt
import time
import numpy as np

import os

os.environ['KMP_DUPLICATE_LIB_OK'] = 'True'

# 设置随机种子
torch.manual_seed(42)
np.random.seed(42)

# 检查GPU是否可用
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print(f"使用设备: {device}")

# 数据预处理和加载
def load_mnist(batch_size=128, val_ratio=0.1):
    """加载MNIST数据集并划分验证集"""
    transform = transforms.Compose([
        transforms.ToTensor(),
        transforms.Normalize((0.1307,), (0.3081,))  # 归一化到[-1, 1]
    ])

    # 下载训练集和测试集
    train_dataset = datasets.MNIST(
        root='./data',
        train=True,
        download=True,
        transform=transform
    )

    test_dataset = datasets.MNIST(
        root='./data',
        train=False,
        download=True,
        transform=transform
    )

    # 划分训练集和验证集
    dataset_size = len(train_dataset)
    val_size = int(val_ratio * dataset_size)
    train_size = dataset_size - val_size

    train_subset, val_subset = random_split(
        train_dataset, [train_size, val_size],
        generator=torch.Generator().manual_seed(42)
    )

    # 创建数据加载器
    train_loader = DataLoader(
        train_subset,
        batch_size=batch_size,
        shuffle=True
    )

    val_loader = DataLoader(
        val_subset,
        batch_size=batch_size,
        shuffle=False
    )

    test_loader = DataLoader(
        test_dataset,
        batch_size=batch_size,
        shuffle=False
    )

    print(f"训练集大小: {len(train_subset)}")
    print(f"验证集大小: {len(val_subset)}")
    print(f"测试集大小: {len(test_dataset)}")

    return train_loader, val_loader, test_loader


# 定义MLP模型
class DeepMLP(nn.Module):
    def __init__(self, input_size=784, hidden_layers=2, hidden_size=20, num_classes=10):
        super(DeepMLP, self).__init__()

        self.input_size = input_size

        # 输入层
        self.input_layer = nn.Linear(input_size, hidden_size)

        # 2个隐藏层
        self.hidden_layers = nn.ModuleList()
        for i in range(hidden_layers):
            self.hidden_layers.append(nn.Linear(hidden_size, hidden_size))

        # 输出层
        self.output_layer = nn.Linear(hidden_size, num_classes)

        # 激活函数
        self.activation = nn.Sigmoid()

        # 初始化权重
        self._initialize_weights()

    def _initialize_weights(self):
        """初始化权重"""
        for layer in self.hidden_layers:
            nn.init.xavier_normal_(layer.weight)
            nn.init.zeros_(layer.bias)

        nn.init.xavier_normal_(self.output_layer.weight)
        nn.init.zeros_(self.output_layer.bias)

    def forward(self, x):
        # 展平输入
        x = x.view(-1, self.input_size)

        # 输入层
        x = self.input_layer(x)
        x = self.activation(x)

        # 隐藏层
        for i, layer in enumerate(self.hidden_layers):
            x = layer(x)
            x = self.activation(x)

        # 输出层（不使用激活函数，因为后面用CrossEntropyLoss）
        x = self.output_layer(x)

        return x


# 计算验证集损失和准确率
def evaluate_val_loss_accuracy(model, val_loader, criterion):
    """计算验证集损失和准确率"""
    model.eval()
    val_loss = 0.0
    correct = 0
    total = 0

    with torch.no_grad():
        for data, targets in val_loader:
            data, targets = data.to(device), targets.to(device)
            outputs = model(data)
            loss = criterion(outputs, targets)
            val_loss += loss.item()

            _, predicted = outputs.max(1)
            total += targets.size(0)
            correct += predicted.eq(targets).sum().item()

    val_loss = val_loss / len(val_loader)
    val_accuracy = 100. * correct / total

    return val_loss, val_accuracy


# 评估函数
def evaluate_model(model, test_loader):
    """评估模型性能"""
    model.eval()
    correct = 0
    total = 0

    with torch.no_grad():
        for data, targets in test_loader:
            data, targets = data.to(device), targets.to(device)
            outputs = model(data)
            _, predicted = outputs.max(1)
            total += targets.size(0)
            correct += predicted.eq(targets).sum().item()

    accuracy = 100. * correct / total
    return accuracy


# 绘制训练曲线
def plot_training_curves(train_losses, train_accuracies, val_losses, val_accuracies, test_accuracies):
    """绘制训练损失和准确率曲线"""
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(10, 5))

    epochs = range(1, len(train_losses) + 1)

    # 损失曲线
    ax1.plot(epochs, train_losses, label='Training Loss', linewidth=2)
    ax1.plot(epochs, val_losses, label='Validation Loss', linewidth=2)
    ax1.set_xlabel('Epoch')
    ax1.set_ylabel('Loss')
    ax1.set_title('Training and Validation Loss')
    ax1.legend()
    ax1.grid(True)

    # 准确率曲线
    ax2.plot(epochs, train_accuracies, label='Training Accuracy', linewidth=2)
    ax2.plot(epochs, val_accuracies, label='Validation Accuracy', linewidth=2)
    ax2.plot(epochs, test_accuracies, label='Test Accuracy', linewidth=2)
    ax2.set_xlabel('Epoch')
    ax2.set_ylabel('Accuracy (%)')
    ax2.set_title('Training, Validation and Test Accuracy')
    ax2.legend()
    ax2.grid(True)

    plt.tight_layout()
    plt.show()


# 可视化一些测试结果
def visualize_predictions(model, test_loader, num_samples=10):
    """可视化模型预测结果"""
    model.eval()
    data_iter = iter(test_loader)
    images, labels = next(data_iter)
    images, labels = images.to(device), labels.to(device)

    with torch.no_grad():
        outputs = model(images)
        _, predicted = outputs.max(1)

    # 转换回CPU用于绘图
    images = images.cpu()
    labels = labels.cpu()
    predicted = predicted.cpu()

    # 绘制结果
    fig, axes = plt.subplots(2, 5, figsize=(15, 6))
    axes = axes.ravel()

    for i in range(num_samples):
        axes[i].imshow(images[i].squeeze(), cmap='gray')
        axes[i].set_title(f'True: {labels[i]}\nPred: {predicted[i]}')
        axes[i].axis('off')

        # 如果预测错误，用红色标题
        if labels[i] != predicted[i]:
            axes[i].title.set_color('red')

    plt.tight_layout()
    plt.show()

# 训练函数
def train_model(model, train_loader, val_loader, test_loader, num_epochs=50, learning_rate=0.1):
    """训练模型"""

    # 定义损失函数和优化器
    criterion = nn.CrossEntropyLoss()
    optimizer = optim.SGD(model.parameters(), lr=learning_rate, momentum=0.9)

    # 学习率调度器
    scheduler = optim.lr_scheduler.StepLR(optimizer, step_size=15, gamma=0.5)

    # 记录训练过程
    train_losses = []
    train_accuracies = []
    val_losses = []
    val_accuracies = []
    test_accuracies = []

    print("开始训练...")
    print(
        f"{'Epoch':^6} | {'Train Loss':^10} | {'Train Acc':^9} | {'Val Loss':^9} | {'Val Acc':^8} | {'Test Acc':^9} | {'Time':^8}")
    print("-" * 95)

    for epoch in range(num_epochs):
        start_time = time.time()

        # 训练模式
        model.train()
        running_loss = 0.0
        correct = 0
        total = 0

        for batch_idx, (data, targets) in enumerate(train_loader):
            data, targets = data.to(device), targets.to(device)

            # 前向传播
            outputs = model(data)
            loss = criterion(outputs, targets)

            # 反向传播
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

            # 统计
            running_loss += loss.item()
            _, predicted = outputs.max(1)
            total += targets.size(0)
            correct += predicted.eq(targets).sum().item()

        # 计算训练准确率
        train_acc = 100. * correct / total
        train_loss = running_loss / len(train_loader)

        # 计算验证集损失和准确率
        val_loss, val_acc = evaluate_val_loss_accuracy(model, val_loader, criterion)

        # 评估测试集
        test_acc = evaluate_model(model, test_loader)

        # 更新学习率
        scheduler.step()

        # 记录结果
        train_losses.append(train_loss)
        train_accuracies.append(train_acc)
        val_losses.append(val_loss)
        val_accuracies.append(val_acc)
        test_accuracies.append(test_acc)

        epoch_time = time.time() - start_time

        print(
            f"{epoch + 1:^6} | {train_loss:^10.4f} | {train_acc:^9.2f} | {val_loss:^9.4f} | {val_acc:^8.2f} | {test_acc:^9.2f} | {epoch_time:^8.2f}")

    return train_losses, train_accuracies, val_losses, val_accuracies, test_accuracies

# 主函数
def main():
    # 超参数
    batch_size = 128
    num_epochs = 10
    learning_rate = 0.1
    hidden_layers = 2
    hidden_size = 20
    val_ratio = 0.1  # 验证集比例

    # 加载数据
    print("加载MNIST数据集...")
    train_loader, val_loader, test_loader = load_mnist(batch_size, val_ratio)

    # 创建模型
    print("创建模型...")
    model = DeepMLP(
        input_size=784,
        hidden_layers=hidden_layers,
        hidden_size=hidden_size,
        num_classes=10
    ).to(device)

    # 打印模型信息
    print(f"模型参数总数: {sum(p.numel() for p in model.parameters()):,}")
    print(f"隐藏层数: {hidden_layers}")
    print(f"每层神经元数: {hidden_size}")
    print(f"激活函数: Sigmoid")
    print(f"优化器: SGD")
    print(f"验证集比例: {val_ratio * 100}%")

    # 训练模型
    train_losses, train_accuracies, val_losses, val_accuracies, test_accuracies = train_model(
        model, train_loader, val_loader, test_loader, num_epochs, learning_rate)

    # 最终评估
    final_test_acc = evaluate_model(model, test_loader)
    final_val_acc = val_accuracies[-1] if val_accuracies else 0
    final_train_acc = train_accuracies[-1] if train_accuracies else 0

    print(f"\n{'=' * 60}")
    print("最终性能结果:")
    print(f"{'=' * 60}")
    print(f"训练准确率: {final_train_acc:.2f}%")
    print(f"验证准确率: {final_val_acc:.2f}%")
    print(f"测试准确率: {final_test_acc:.2f}%")

    # 绘制训练曲线
    plot_training_curves(train_losses, train_accuracies, val_losses, val_accuracies, test_accuracies)

    # 可视化一些预测结果
    visualize_predictions(model, test_loader)

if __name__ == "__main__":
    main()