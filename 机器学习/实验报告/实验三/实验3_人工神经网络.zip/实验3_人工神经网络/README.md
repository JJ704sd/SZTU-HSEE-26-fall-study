# 人工神经网络实验源码与结果

保留实验代码、已有结果图、训练日志，以及 q3_manual 下的小样本 CSV。
Fashion-MNIST/CIFAR-10 完整数据缓存未打包；common.py 和 mnist.py 使用 download=True，首次运行会下载到 data/。

在本目录准备项目环境并安装 requirements.txt 中记录的依赖后，分别运行 q1_fashion、q2_cifar、q3_manual 中对应脚本。manual.py 使用相对路径，请先切换到 q3_manual 目录。

本包清除了身份字段、用户路径、IDE 配置、Python 缓存、安装日志及 Word 临时锁文件。
训练结果沿用原始归档；本次仅做脱敏与打包，没有重新训练或验证模型效果。
