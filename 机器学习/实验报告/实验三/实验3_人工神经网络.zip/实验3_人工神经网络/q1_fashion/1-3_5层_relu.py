import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from common import *

# 1-3
trl, vl, tel = load('fashion')
m = MLP(784, 64, 5, 'relu').to(device)
save = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'fig_1-3.png')
train(m, trl, vl, tel, 30, 0.01, '1-3 hidden=64 layers=5 ReLU+He lr=0.01', save)
