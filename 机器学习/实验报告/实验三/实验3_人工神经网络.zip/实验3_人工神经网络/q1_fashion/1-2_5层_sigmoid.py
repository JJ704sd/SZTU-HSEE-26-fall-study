import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from common import *

# 1-2
trl, vl, tel = load('fashion')
m = MLP(784, 64, 5, 'sigmoid').to(device)
save = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'fig_1-2.png')
train(m, trl, vl, tel, 30, 0.01, '1-2 hidden=64 layers=5 Sigmoid lr=0.01', save)
