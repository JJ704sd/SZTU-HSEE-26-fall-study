import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from common import *

# 1-1
trl, vl, tel = load('fashion')
m = MLP(784, 64, 2, 'sigmoid').to(device)
save = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'fig_1-1.png')
train(m, trl, vl, tel, 30, 0.01, '1-1 hidden=64 layers=2 Sigmoid lr=0.01', save)
