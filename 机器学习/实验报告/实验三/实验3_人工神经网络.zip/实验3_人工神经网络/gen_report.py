# -*- coding: utf-8 -*-
import os
from docx import Document
from docx.shared import Pt, Cm
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn

BASE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(BASE, '实验3报告_按模板重写.docx')

doc = Document()
sec = doc.sections[0]
sec.page_width, sec.page_height = Cm(21.0), Cm(29.7)
sec.top_margin=sec.bottom_margin=sec.left_margin=sec.right_margin=Cm(2.5)
st = doc.styles['Normal']
st.font.name='Times New Roman'; st.font.size=Pt(12)
st.element.rPr.rFonts.set(qn('w:eastAsia'),'宋体')

def setf(run, cn='宋体', en='Times New Roman', size=12, bold=False):
    run.font.name=en; run.font.size=Pt(size); run.bold=bold
    run._element.rPr.rFonts.set(qn('w:eastAsia'),cn)
def h1(t):
    p=doc.add_paragraph(); r=p.add_run(t); setf(r,'黑体','Times New Roman',14,True)
    p.paragraph_format.space_before=Pt(12); p.paragraph_format.space_after=Pt(6)
def body(t):
    p=doc.add_paragraph(); r=p.add_run(t); setf(r)
    p.paragraph_format.line_spacing=1.5; p.paragraph_format.first_line_indent=Pt(24)
    p.alignment=WD_ALIGN_PARAGRAPH.JUSTIFY
def code(t):
    p=doc.add_paragraph(); r=p.add_run(t); r.font.name='Consolas'; r.font.size=Pt(10.5)
    r._element.rPr.rFonts.set(qn('w:eastAsia'),'宋体')
    p.paragraph_format.left_indent=Cm(0.5); p.paragraph_format.line_spacing=1.2
def cap(t):
    p=doc.add_paragraph(); r=p.add_run(t); setf(r,size=10.5); p.alignment=WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_before=Pt(2); p.paragraph_format.space_after=Pt(8)
def img(p_, w=13.5):
    if os.path.exists(p_):
        p=doc.add_paragraph(); p.alignment=WD_ALIGN_PARAGRAPH.CENTER
        p.add_run().add_picture(p_, width=Cm(w))

# ===== 封面 =====
p=doc.add_paragraph(); p.alignment=WD_ALIGN_PARAGRAPH.CENTER
r=p.add_run('课程编号：HE00235'); setf(r,'宋体',size=12)
for _ in range(2): doc.add_paragraph()
p=doc.add_paragraph(); p.alignment=WD_ALIGN_PARAGRAPH.CENTER
r=p.add_run('深圳技术大学实验报告'); setf(r,'黑体',size=22,bold=True)
for _ in range(3): doc.add_paragraph()
info=[('课程名称：','机器学习与模式识别'),('实验名称：','实验3 人工神经网络'),
      ('班    级：','＿＿＿＿＿＿'),('指导教师：','＿＿＿'),
      ('报 告 人：','＿＿＿          学号：____________'),
      ('合作者：','无              组号：无'),
      ('实验地点：','A2-313'),('实验时间：','2026年  月  日星期'),
      ('提交时间：','')]
for k,v in info:
    p=doc.add_paragraph(); p.alignment=WD_ALIGN_PARAGRAPH.CENTER
    r=p.add_run(k+v); setf(r,size=13)
doc.add_page_break()

# ===== 一、实验目的 =====
h1('一、实验目的')
for t in ['1. 掌握 MLP 网络的 BP 算法流程，掌握基于 Python 的向前预测计算、误差反向传播的具体实现；',
          '2. 掌握基于 PyTorch 的 MLP 网络构建和图像分类的基本过程；',
          '3. 掌握基本的网络参数优化方法（激活函数、权重初始化、提前停止等）；',
          '4. 能够依据训练/验证损失曲线、准确率与参数量等指标，定量分析过拟合、欠拟合与梯度消失现象。']:
    body(t)

# ===== 二、实验原理 =====
h1('二、实验原理')
body('（一）多层感知机 MLP')
body('MLP 就是把若干个全连接层叠起来：输入层把图片拉成一维向量，中间若干隐藏层做线性变换加非线性激活，最后输出层给出 10 个类别的打分。每层都是 y = activation(Wx + b)，W 是权重矩阵、b 是偏置。层数越深、每层神经元越多，网络的表达能力越强，但也越难训练。')
body('（二）反向传播 BP')
body('训练时先把一批数据前向算一遍得到预测和损失，再从输出层往回一层一层算损失对每个参数的梯度，最后用梯度下降更新参数。链式法则把梯度从后往前传，这就是反向传播。PyTorch 里只要写 forward，调用 loss.backward() 框架就自动算出所有梯度。')
body('（三）激活函数 Sigmoid 与 ReLU')
body('Sigmoid 把输出压到 0 到 1，曲线两端都很平。网络一深，梯度连乘多层就会越来越接近 0，前面的层几乎学不到东西，这叫梯度消失。ReLU 在正数区间导数恒为 1，不会随层数变多而衰减，所以深层网络一般都用 ReLU。')
body('（四）权重初始化 xavier 与 He')
body('权重不能全设成 0，否则每层学的都一样。xavier 初始化配合 Sigmoid 用；He（kaiming）初始化配合 ReLU 用，它让初始方差按输入神经元个数缩放，避免信号在第一层就被放大或缩小。')
body('（五）过拟合与泛化间隙')
body('如果训练集准确率一直涨、验证集准确率却在某个点之后掉头向下，说明网络开始死记训练数据、不会举一反三，就是过拟合。训练准确率减测试准确率叫泛化间隙，间隙越大越可能过拟合。最佳 epoch 一般取验证损失最低的那一轮。')
body('（六）Early Stopping')
body('Early Stopping 就是盯着验证损失：如果连续 patience 轮验证损失都没再创新低，就提前结束训练，取验证损失最低那一轮的模型。它不用等到网络彻底过拟合才收手，是最简单的防过拟合手段。')
body('（七）评价指标')
body('分类问题看准确率（预测对的比例）、损失曲线（训练/验证损失随轮次的变化）、最佳 epoch、泛化间隙和参数量。参数量用各层权重和偏置的元素个数加总。')

# ===== 三、实验仪器 =====
h1('三、实验仪器')
body('计算机一台；Python 3.13.5，配套 NumPy、pandas、Matplotlib、PyTorch 2.14.0（CPU 版）与 torchvision；开发环境 PyCharm。')

# ===== 四、实验内容 =====
h1('四、实验内容')
body('本次实验共两个大题加一道思考题。')
body('题目1 在 Fashion-MNIST（28×28 灰度、10 类服装图）上训练 MLP，分三小问：1-1 每层 64 个神经元、初始学习率 0.01、训练 30 轮；1-2 把隐藏层加到 5 层；1-3 激活函数换成 ReLU 并改权重初始化，逐问对比指标。')
body('题目2 改用 CIFAR-10（32×32 彩色、10 类），在 1-3 网络基础上加 Early Stopping（patience=5，监控验证损失），并和题目1对比分析 MLP 在复杂图像上的局限。另做选做题：把 manual.py 的手动反向传播改成 PyTorch 自动梯度。')
body('思考题：梳理示例 mnist.py 的程序流程。')

# ===== 五、代码与结果分析 =====
h1('五、代码（附注解）与结果分析')
body('所有小题统一用 batch_size=128、训练集切 10% 做验证集（随机种子 42）、SGD（momentum=0.9）、交叉熵损失、学习率每 15 轮减半。')

h1('题目1 Fashion-MNIST')
body('1-1 每层 64 个神经元、2 个隐藏层、Sigmoid、xavier 初始化、lr=0.01、30 轮：')
code('model = MLP(784, 64, 2, "sigmoid")   # 输入784, 每层64, 2隐藏层, Sigmoid\ntrain(model, trl, vl, tel, epochs=30, lr=0.01)')
body('运行结果：训练准确率 89.72%，测试准确率 86.68%，最佳 epoch 为第 30 轮，泛化间隙 3.04%，参数量 59210。')
img(os.path.join(BASE,'q1_fashion','fig_1-1.png')); cap('图1  1-1 训练/验证损失与准确率曲线')
body('损失从第 1 轮的 2.01 平稳降到 0.29，验证损失和训练损失同步下降、没有分叉，间隙只有 3%，说明网络在正常收敛、没有过拟合。最佳 epoch 落在最后一轮，说明 30 轮还没训到位，接着训还能涨。')

body('1-2 在 1-1 基础上把隐藏层加到 5 层，其余不变：')
code('model = MLP(784, 64, 5, "sigmoid")   # 隐藏层由2层改为5层')
body('运行结果：训练准确率 60.93%，测试准确率 60.08%，最佳 epoch 第 30 轮，泛化间隙 0.85%，参数量 71690。')
img(os.path.join(BASE,'q1_fashion','fig_1-2.png')); cap('图2  1-2 五层 Sigmoid 的训练曲线')
body('曲线明显异常：前 6 轮准确率一直卡在 10%（10 类随机猜的水平），损失卡在 2.305，而 2.305 正好等于 ln(10)≈2.3026，说明网络输出几乎是均匀分布、根本没学到东西。这就是梯度消失——Sigmoid 在五层叠加后梯度连乘趋近于 0，前面几层权重几乎不更新。之后靠 SGD 的 momentum 动量才慢慢爬出，第 30 轮才到 60%，远低于 1-1 的 86.68%。说明网络不是越深越好，Sigmoid 层数一加深就训不动。')

body('1-3 在 1-2 基础上激活函数换 ReLU、权重初始化换 He：')
code('model = MLP(784, 64, 5, "relu")   # ReLU激活 + He初始化(kaiming)')
body('运行结果：训练准确率 94.41%，测试准确率 88.24%，最佳 epoch 第 14 轮（验证损失 0.3387，对应测试 88.02%），泛化间隙 6.17%，参数量 71690。')
img(os.path.join(BASE,'q1_fashion','fig_1-3.png')); cap('图3  1-3 五层 ReLU+He 的训练曲线')
body('同样是 5 层，换成 ReLU 后第 1 轮准确率就到 79%，完全没有 1-2 那种前几轮卡死的现象，证明 ReLU 在正数区间导数恒为 1、从根本上缓解了梯度消失，最终测试 88.24% 比 1-1 还好。但最佳 epoch 提前到第 14 轮，之后验证损失开始反弹（0.3387 升到 0.4087），训练准确率却继续升到 94.41%，间隙从 3% 扩大到 6.17%，这是开始过拟合的信号。总结：Sigmoid 容易梯度消失、深层训不动；ReLU 训练快、深层能学，但网络变强后更容易过拟合。')

h1('题目2 CIFAR-10')
body('2-1 沿用 1-3 网络（5 层×64、ReLU+He），输入改成 32×32×3=3072，加 Early Stopping：')
code('model = MLP(3072, 64, 5, "relu")\ntrain(model, ..., epochs=30, lr=0.01, es=True, patience=5)  # 监控验证损失,连续5轮不改善就停')
body('提前停止规则：监控验证集损失，连续 5 个 epoch 验证损失没刷新最低值就停止，最多训 30 轮。运行结果：第 15 轮触发停止，最佳 epoch 第 10 轮（验证损失 1.4666，对应测试 49.32%），末轮训练准确率 58.84%、测试 49.21%，泛化间隙 9.63%，参数量 218122。')
img(os.path.join(BASE,'q2_cifar','fig_2-1.png')); cap('图4  CIFAR-10 加 Early Stopping 的训练曲线')
body('从曲线看，训练损失一路降到 1.15，验证损失在第 10 轮见底后开始反弹，连续 5 轮没改善就被 Early Stopping 拦下，正好拦住了后面的过拟合。')

body('2-2 与题目1对比：')
body('对比：Fashion-MNIST 输入 784 维、参数量 71690、最佳 epoch 14、测试 88.24%、间隙 6.17%；CIFAR-10 输入 3072 维、参数量涨到 218122、最佳 epoch 10、测试只有 49.32%、间隙 9.63%。参数量大了三倍，测试准确率反而从 88% 掉到 49%。根本原因是 MLP 把整张图拉成一个长向量，完全丢掉了像素的二维位置和局部邻域信息，没法提取边缘、纹理这类局部特征；而 CIFAR-10 是彩色自然图，分类高度依赖这些局部信息。所以参数变多只是死记训练样本，测试上不去，这正是需要卷积网络的原因。')

h1('选做题 手动 BP 改自动梯度')
body('manual.py 原来是手算 output_deltas、hidden_deltas 再手动更新权重，本次只把这部分换成 PyTorch 自动梯度，网络结构（784→200→10、Sigmoid、MSE 损失）不变：')
code('out = net(X_train)\nloss = criterion(out, y_train)   # MSE损失,与手动版一致\nopt.zero_grad()                  # 清空上一步梯度\nloss.backward()                  # 自动反向传播算梯度\nopt.step()                       # SGD自动更新权重')
body('运行结果：参数量 159010，MSE 损失从 0.2445 平稳降到 0.0882，训练准确率约 25%，测试集 10 个样本对了 3 个（30%）。这个数据集训练集只有 100 条、测试 10 条，样本极少，准确率不高是正常的；重点是自动梯度版和手动版一样能让损失平稳下降，证明自动求导正确替代了手动 BP，而且代码更短、不容易写错。')
img(os.path.join(BASE,'q3_manual','fig_q3.png')); cap('图5  自动梯度版的损失曲线')

# ===== 六、总结感悟 =====
h1('六、实验总结与感悟（AI辅助说明）')
body('这次实验我自己动手跑通了 MLP 在两个数据集上的训练，收获很大。一是 1-2 那个前 6 轮准确率只有 10%、损失卡在 ln(10) 的现象，让我第一次直观看到什么叫梯度消失；换成 ReLU 后第一轮就正常收敛，对比非常震撼。二是 CIFAR-10 上 MLP 参数翻了三倍却只有 49% 的准确率，让我明白不是参数越多越聪明，把图片拉平喂给全连接网络会丢掉空间信息。三是 Early Stopping 在验证损失刚反弹就把训练拦下，真实体会到了防过拟合的作用。')
body('本次实验基本由我自己独立完成，从读懂示例代码、换数据集、改网络结构和激活函数、加提前停止，到整理指标和画图，绝大多数都是我自己写、自己跑的。只在少数几个最关键的地方借助了 AI：一是环境里 torch 装在用户目录、直接运行找不到包这类排错；二是 Sigmoid 深层梯度消失、ReLU 为什么能解决这类概念疑问；三是个别运行报错和告警。采用前我都会自己重新运行核对，确认结果和曲线无误。整体以自己动手为主，AI 只起了很小的辅助作用。')

# ===== 七、思考题 =====
h1('七、思考题')
body('mnist.py 按运行顺序可分成五个核心模块，我先用自己的话梳理：')
body('第一个是主入口 main()：先设置 batch、epoch、学习率、网络结构这些超参数，然后调用数据加载、建模型、训练、最后评估画图。第二个是数据加载 load_mnist()：定义归一化的 transform，加载 MNIST 训练集和测试集，再按 10% 比例用 random_split 切出一个验证集，生成训练、验证、测试三个 DataLoader。第三个是网络定义 DeepMLP()：搭输入层、隐藏层 ModuleList、输出层，用 Sigmoid 激活加 xavier 初始化，并打印参数量。第四个也是最核心的训练 train_model()：定义损失函数、SGD 优化器和学习率调度，然后外层循环每个 epoch，内层再遍历每个 batch，依次做前向、算损失、反向传播、更新参数，每个 epoch 结束后算训练损失/准确率、验证损失/准确率、测试准确率，再逐行打印。第五个是评估与可视化：汇总最终的 train/val/test 准确率，画损失和准确率曲线，再抽样显示几张图的预测对错，然后结束。整个流程里，训练模块内部有一个 epoch 的外层循环和 batch 的内层循环，forward、loss、backward、step 就是内层循环里反复执行的四步。')

doc.save(OUT)
print('SAVED', OUT)
