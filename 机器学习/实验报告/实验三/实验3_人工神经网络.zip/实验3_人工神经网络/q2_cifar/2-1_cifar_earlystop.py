import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from common import *

# 2-1
trl, vl, tel = load('cifar')
m = MLP(3072, 64, 5, 'relu').to(device)
save = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'fig_2-1.png')
train(m, trl, vl, tel, 30, 0.01, '2-1 CIFAR10 5x64 ReLU+He +EarlyStop(p=5)', save, es=True, patience=5)
