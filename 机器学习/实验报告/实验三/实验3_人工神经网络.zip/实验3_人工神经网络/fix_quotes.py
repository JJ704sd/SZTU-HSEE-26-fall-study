# -*- coding: utf-8 -*-
from docx import Document
import os
p = os.path.join(os.path.dirname(os.path.abspath(__file__)), '实验3报告_按模板重写.docx')
doc = Document(p)

def fix(t):
    out=[]; open_q=True
    for ch in t:
        if ch=='"':
            out.append('“' if open_q else '”'); open_q=not open_q
        else: out.append(ch)
    return ''.join(out)

n=0
for para in doc.paragraphs:
    for r in para.runs:
        # 跳过代码块(Consolas)
        if r.font.name=='Consolas': continue
        if '"' in r.text:
            r.text = fix(r.text); n+=1
for tb in doc.tables:
    for row in tb.rows:
        for c in row.cells:
            for para in c.paragraphs:
                for r in para.runs:
                    if '"' in r.text: r.text=fix(r.text); n+=1
doc.save(p)
print('fixed runs:', n)
