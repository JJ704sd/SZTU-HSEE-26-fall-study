#ifndef __LED_H
#define __LED_H
#include "sys.h"

//////////////////////////////////////////////////////////////////////////////////	 
//LED�˿ڶ���
#define LED0 PGout(13)	// DS0
#define LED1 PGout(14)	// DS1	 

void LED_Init(void);//��ʼ��		 				    
#endif
