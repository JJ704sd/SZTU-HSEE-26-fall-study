import traceback, sys
def excepthook(exc_type, exc_value, exc_tb):
    traceback.print_exception(exc_type, exc_value, exc_tb)
    QtWidgets.QMessageBox.critical(None, "未捕获异常", str(exc_value))
sys.excepthook = excepthook

import queue
from PyQt5 import  QtWidgets,uic, QtCore
from thead_config import config
from thead_config.tcp_thread import TcpSenderThread
# from thead_config.video_thread import VideoThread
# from PyQt5.QtGui import QImage, QPixmap, QPainter, QPen
# from thead_config.tracker import  SmartTracker

def message_cb(status, message):
    print(f"status: {status} {message}")


class Main_Windown(QtWidgets.QMainWindow):
    def __init__(self):
        super().__init__()
        self.cmd_queue = queue.Queue()
        # 👇 使用 uic 动态加载 .ui 文件到当前窗口（self）
        uic.loadUi('untitled.ui', self)  # ✅ 关键：加载 UI
        # 设置标题
        self.setWindowTitle('STM32智能小车实验系统')

        # 按钮事件
        self.IP_connect.clicked.connect(lambda: self.IP_connet_callback())
        self.forward_button.pressed.connect(lambda: self.send_cmd(config.data_forward))
        self.forward_button.released.connect(lambda: self.send_cmd(config.data_stop))
        self.backward_button.pressed.connect(lambda: self.send_cmd(config.data_backward))
        self.backward_button.released.connect(lambda: self.send_cmd(config.data_stop))
        self.left_button.pressed.connect(lambda: self.send_cmd(config.data_left))
        self.left_button.released.connect(lambda: self.send_cmd(config.data_stop))
        self.right_button.pressed.connect(lambda: self.send_cmd(config.data_right))
        self.right_button.released.connect(lambda: self.send_cmd(config.data_stop))

        # 标志位设置
        self.IP_connect_flag = False            # IP连接标志位
        self.vision_nav_mode = False            # 视频框选追踪
        self.tracking = False

        # 相关参数
        self.IP_text = None
        self.cv_image = None
        self.video_url = None
        self.scaled_pixmap = None

        self.frame_width = 640
        self.frame_height = 480

    def IP_connet_callback(self):
        self.IP_text = self.lineEdit.text()
        self.video_url = f"http://{self.IP_text}:8080/?action=stream"
        self.tcp_thread = TcpSenderThread(self.IP_text, 2001, self.cmd_queue)
        # 把错误信号连到槽函数
        self.tcp_thread.error_signal.connect(self.show_error)
        self.tcp_thread.connected_signal.connect(self.show_connected)
        self.tcp_thread.start()

    def send_cmd(self, cmd="", speed=None, slider_id=None):
        if self.IP_connect_flag:

            if speed is not None and slider_id is not None:
                cmd = bytes([0xFF, 0x02, slider_id, speed, 0xFF])
            print(cmd)
            self.cmd_queue.put(cmd)
        else:
            print("IP未连接")
    # 连接成功提示
    def show_connected(self):
        QtWidgets.QMessageBox.information(self, "连接成功",f"已连接{self.IP_text}")
        self.IP_connect_flag = True
        print("开始获得视频流")
    # 用来判断网络是否连接超时与错误
    def show_error(self, msg):
        QtWidgets.QMessageBox.critical(self, "网络错误", msg)
        self.IP_connect_flag = False

if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    main_win = Main_Windown()
    # 创建窗口
    main_win.show()
    # 进入程序的主循环，并通过exit函数确保主循环安全结束(该释放资源的一定要释放)
    sys.exit(app.exec_())