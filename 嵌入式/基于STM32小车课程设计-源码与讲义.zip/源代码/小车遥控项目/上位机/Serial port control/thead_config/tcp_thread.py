import socket
import queue
import time
from PyQt5.QtCore import QThread, pyqtSignal
from PyQt5.QtWidgets import QApplication, QMessageBox
# TCP发送线程
class TcpSenderThread(QThread):
    error_signal = pyqtSignal(str)  # 可选：用于错误信息传递
    connected_signal = pyqtSignal()
    def __init__(self, host, port, cmd_queue):
        super().__init__()
        self.host = host
        self.port = port
        self.cmd_queue = cmd_queue
        self.sock = None
        self.running = True

    def run(self):
        try:
            self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.sock.settimeout(5)
            self.sock.connect((self.host, self.port))
            self.sock.settimeout(None)
            self.connected_signal.emit()  # 连接成功通知主线程
            while self.running:
                try:
                    cmd = self.cmd_queue.get(timeout=0.1)
                    self.sock.sendall(cmd)
                except queue.Empty:
                    continue
        except Exception as e:
            msg = f"TCP连接异常: {e}"
            print(msg)
            self.error_signal.emit(msg)
            if self.sock:
                self.sock.close()
            time.sleep(2)

    def stop(self):
        self.running = False
        self.wait()