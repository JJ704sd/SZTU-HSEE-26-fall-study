#ifndef __FUNCTION_H
#define	__FUNCTION_H


void Communication_Decode(void);
void Cruising(void);
extern int Communication_Decode_flag;

#endif /* __FUNCTION_H */


