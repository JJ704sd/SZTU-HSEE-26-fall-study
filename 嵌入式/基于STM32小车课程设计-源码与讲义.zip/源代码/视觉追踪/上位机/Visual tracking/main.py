import traceback, sys
def excepthook(exc_type, exc_value, exc_tb):
    traceback.print_exception(exc_type, exc_value, exc_tb)
    QtWidgets.QMessageBox.critical(None, "未捕获异常", str(exc_value))
sys.excepthook = excepthook
import threading
import  untitled
import queue
import cv2
from PyQt5 import  QtWidgets,uic, QtCore
from thead_config import config
from thead_config.tcp_thread import TcpSenderThread
from thead_config.video_thread import VideoThread
from PyQt5.QtGui import QImage, QPixmap, QPainter, QPen
from thead_config.tracker import  SmartTracker

def message_cb(status, message):
    print(f"status: {status} {message}")


class Main_Windown(QtWidgets.QMainWindow):
    def __init__(self):
        super().__init__()
        self.cmd_queue = queue.Queue()
        # 👇 使用 uic 动态加载 .ui 文件到当前窗口（self）
        uic.loadUi('untitled.ui', self)  # ✅ 关键：加载 UI
        # 设置标题
        self.setWindowTitle('STM32智能小车实验系统')

        # 按钮事件
        self.IP_connect.clicked.connect(lambda: self.IP_connet_callback())
        self.video_button.clicked.connect(lambda: (self.send_cmd(config.data_stop),
                                                            self.send_cmd(config.data_Manual_control_mode),
                                                            self.send_cmd(speed=15, slider_id=0x02),
                                                            self.send_cmd(speed=15, slider_id=0x01),
                                                            setattr(self, "vision_nav_mode", True),  # 给对象动态设置属性的值
                                                            setattr(self, "tracking", False)))
        # 标志位设置
        self.IP_connect_flag = False            # IP连接标志位
        self.vision_nav_mode = False            # 视频框选追踪
        self.tracking = False

        # 相关参数
        self.IP_text = None
        self.cv_image = None
        self.video_url = None
        self.scaled_pixmap = None

        self.frame_width = 640
        self.frame_height = 480

        self.target_h = None
        self.target_w = None
        self.center_x = None
        self.center_y = None
        self.selecting = False

        # 画框相关
        self.drawing = False  # 正在拖拽
        self.box_start = None  # QPoint 起点
        self.box_end = None  # QPoint 实时终点

        self.mouse_flag = False
        self.tracker_start_flag = False
        self.video_frame = None
        self.video_label.paintEvent = self._paint_video_label
        self.tracker = None
        # 捕获videolabel上的事件到mainwindow上处理
        self.video_label.installEventFilter(self)
    def IP_connet_callback(self):
        self.IP_text = self.lineEdit.text()
        self.video_url = f"http://{self.IP_text}:8080/?action=stream"
        self.tcp_thread = TcpSenderThread(self.IP_text, 2001, self.cmd_queue)
        # 把错误信号连到槽函数
        self.tcp_thread.error_signal.connect(self.show_error)
        self.tcp_thread.connected_signal.connect(self.show_connected)
        self.tcp_thread.start()
    # 下发指令
    def send_cmd(self, cmd="", speed=None, slider_id=None):
        if self.IP_connect_flag:

            if speed is not None and slider_id is not None:
                cmd = bytes([0xFF, 0x02, slider_id, speed, 0xFF])
            print(cmd)
            self.cmd_queue.put(cmd)
        else:
            print("IP未连接")
    # 连接成功提示
    def show_connected(self):
        QtWidgets.QMessageBox.information(self, "连接成功",f"已连接{self.IP_text}")
        self.IP_connect_flag = True
        print("开始获得视频流")
        # 启动视频线程
        self.video_thread = VideoThread(self.video_url)
        print("开启线程")
        self.video_thread.frame_signal.connect(self.process_frame)
        self.video_thread.start()
    # 用来判断网络是否连接超时与错误
    def show_error(self, msg):
        QtWidgets.QMessageBox.critical(self, "网络错误", msg)
        self.IP_connect_flag = False
    def process_frame(self,frame):
        # 将 OpenCV 的 BGR 格式转换为 RGB
        # 转换为 RGB
        rgb_image = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        # self.video_freame = rgb_image.copy()
        self.video_freame = cv2.resize(rgb_image,(640,480))
        h, w, ch = self.video_freame.shape
        bytes_per_line = ch * w

        if self.vision_nav_mode == True:
            processed_frame = self.video_freame.copy()
        else:
            processed_frame = self.video_freame.copy()
        qimg = QImage(processed_frame.data, w, h, bytes_per_line, QImage.Format_RGB888)
        # 缩放图像
        self.scaled_pixmap = QPixmap.fromImage(qimg)
        # 设置到 label
        self.video_label.setPixmap(self.scaled_pixmap)

    def eventFilter(self, obj, event):
        if obj is not self.video_label:
            return super().eventFilter(obj, event)

        # 只在“视觉导航”模式下才允许画框
        if not self.vision_nav_mode:
            return super().eventFilter(obj, event)

        etype = event.type()

        # 1) 左键按下：开始画框
        if etype == QtCore.QEvent.MouseButtonPress and event.button() == QtCore.Qt.LeftButton:
            self.drawing = True
            self.box_start = event.pos()  # label 坐标
            self.box_end = self.box_start
            return True

        # 2) 鼠标移动：实时更新终点并立即重绘
        elif etype == QtCore.QEvent.MouseMove and self.drawing:
            self.box_end = event.pos()
            self.video_label.update()  # 触发 paintEvent，重画
            return True

        # 3) 左键释放：结束画框
        # 3) 左键释放：结束画框
        elif etype == QtCore.QEvent.MouseButtonRelease and event.button() == QtCore.Qt.LeftButton:
            self.drawing = False
            self.box_end = event.pos()


            # 计算最终框（label 坐标）
            x0, y0 = self.box_start.x(), self.box_start.y()
            x1, y1 = self.box_end.x(), self.box_end.y()
            # 继续原来的逻辑
            x0, x1 = sorted([x0, x1])
            y0, y1 = sorted([y0, y1])
            x1 = min(x1, self.frame_width)
            y1 = min(y1, self.frame_height)
            w = x1 - x0
            h = y1 - y0
            cx = x0 + w//2
            cy = y0 + h//2
            if w > 10 and h > 10:
                # cx, cy, rw, rh = self._label2image(x0, y0, w, h)
                self.center_x, self.center_y = cx, cy
                self.target_w, self.target_h = w, h
                print("框中心/宽高:", cx, cy, w, h)

            self.video_label.update()
            self.box_start = None  # 把起点置空
            self.box_end = None  # 可有可无，顺手清掉
            self.mouse_flag = True  # 表示进行一次鼠标事件
            self.video_label.update()  # 立刻刷新一次，框立即消失
            # 重新初始化
            return True

        return super().eventFilter(obj, event)
    # 新增成员函数
    def _paint_video_label(self, event):
        # 先让 QLabel 正常把视频画面画出来
        QtWidgets.QLabel.paintEvent(self.video_label, event)

        # 如果不在画框状态，直接返回
        if not (self.vision_nav_mode and (self.drawing or self.box_start)):
            return

        painter = QPainter(self.video_label)
        painter.setPen(QPen(QtCore.Qt.red, 2))

        # 计算当前实时框
        x0, y0 = self.box_start.x(), self.box_start.y()
        x1, y1 = self.box_end.x(), self.box_end.y()
        x, y, w, h = min(x0, x1), min(y0, y1), abs(x1 - x0), abs(y1 - y0)
        painter.drawRect(x, y, w, h)

if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    main_win = Main_Windown()
    # 创建窗口
    main_win.show()
    # 进入程序的主循环，并通过exit函数确保主循环安全结束(该释放资源的一定要释放)
    sys.exit(app.exec_())