import requests
import numpy as np
import cv2
import time
from PyQt5.QtCore import QThread, pyqtSignal

class VideoThread(QThread):
    frame_signal = pyqtSignal(np.ndarray)

    def __init__(self, url):
        super().__init__()
        self.url = url
        self.running = True

    def run(self):
        while self.running:
            try:
                stream = requests.get(self.url, stream=True, timeout=5)
                bytes_data = b""
                for chunk in stream.iter_content(chunk_size=4096):
                    if not self.running:
                        break
                    bytes_data += chunk

                    while True:
                        a = bytes_data.find(b'\xff\xd8')
                        b = bytes_data.find(b'\xff\xd9')
                        if a != -1 and b != -1 and b > a:
                            jpg = bytes_data[a:b+2]
                            bytes_data = bytes_data[b+2:]
                            img_array = np.frombuffer(jpg, dtype=np.uint8)
                            frame = cv2.imdecode(img_array, cv2.IMREAD_COLOR)
                            if frame is not None:
                                self.frame_signal.emit(frame)
                        else:
                            break
            except Exception as e:
                print(f"VideoThread error: {e}")
                time.sleep(2)  # 等2秒后重连
    def stop(self):
        self.running = False
        self.wait()
