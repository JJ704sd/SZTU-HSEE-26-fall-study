import cv2
import numpy as np

class KalmanFilter:
    def __init__(self, init_x, init_y):
        self.kf = cv2.KalmanFilter(4, 2)  # 4个状态量（x,y,vx,vy），2个观测量

        # 状态转移矩阵（匀速模型）
        self.kf.transitionMatrix = np.array([
            [1, 0, 1, 0],
            [0, 1, 0, 1],
            [0, 0, 1, 0],
            [0, 0, 0, 1]], dtype=np.float32)

        # 观测矩阵
        self.kf.measurementMatrix = np.array([
            [1, 0, 0, 0],
            [0, 1, 0, 0]], dtype=np.float32)

        # 噪声参数
        self.kf.processNoiseCov = np.eye(4, dtype=np.float32) * 1e-2
        self.kf.measurementNoiseCov = np.eye(2, dtype=np.float32) * 0.1

        # 初始化状态
        self.kf.statePost = np.array([[init_x], [init_y], [0], [0]], dtype=np.float32)

    def predict(self):
        return self.kf.predict()

    def correct(self, measurement):
        measured = np.array([[measurement[0]], [measurement[1]]], dtype=np.float32)
        return self.kf.correct(measured)


class SmartTracker:
    def __init__(self, message_callback):
        self.tracker = None
        self.kf = None
        self.target_kp = None
        self.target_des = None
        self.target_roi = None
        self.failure_count = 0
        self.max_failure = 5
        self.orb = cv2.ORB_create(nfeatures=500)
        self.bf = cv2.BFMatcher(cv2.NORM_HAMMING, crossCheck=True)
        self.tracking = False
        self.message_cb = message_callback

    def start_tracking(self, frame, center_x, center_y, width, height):
        if not self.tracking:
            x_start = int(center_x - width // 2)
            y_start = int(center_y - height // 2)
            x_end = x_start + width
            y_end = y_start + height

            if x_start < 0 or y_start < 0 or x_end > frame.shape[1] or y_end > frame.shape[0]:
                print("框选区域超出画面范围")
                self.message_cb(False, "框选区域超出画面范围")
                return

            # 初始化跟踪器
            self.tracker = cv2.TrackerCSRT_create()
            self.tracker.init(frame, (x_start, y_start, width, height))

            # 初始化卡尔曼滤波器
            self.kf = KalmanFilter(center_x, center_y)

            # 提取目标特征
            self.target_kp, self.target_des, self.target_roi = self.extract_features(frame, (x_start, y_start, width, height))

            self.tracking = True
            self.failure_count = 0
        
    def stop_tracking(self):
        """停止追踪
        """
        self.tracking = False

    def extract_features(self, frame, bbox):
        x, y, w, h = map(int, bbox)
        roi = frame[y:y+h, x:x+w]
        gray = cv2.cvtColor(roi, cv2.COLOR_BGR2GRAY)
        kp, des = self.orb.detectAndCompute(gray, None)
        return kp, des, roi

    def match_features(self, frame):
        if self.target_des is None:
            return None

        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        kp, des = self.orb.detectAndCompute(gray, None)

        if des is not None:
            matches = self.bf.match(self.target_des, des)
            matches = sorted(matches, key=lambda x: x.distance)

            good = matches[:20]
            if len(good) > 10:
                src_pts = np.float32([self.target_kp[m.queryIdx].pt for m in good]).reshape(-1,1,2)
                dst_pts = np.float32([kp[m.trainIdx].pt for m in good]).reshape(-1,1,2)

                M, mask = cv2.findHomography(src_pts, dst_pts, cv2.RANSAC, 5.0)
                if M is not None:
                    h, w = self.target_roi.shape[:2]
                    pts = np.float32([[0,0],[0,h-1],[w-1,h-1],[w-1,0]]).reshape(-1,1,2)
                    dst = cv2.perspectiveTransform(pts, M)
                    return cv2.boundingRect(dst)
        return None

    def process_frame(self, frame):
        working_frame = frame.copy()
        detection = None

        if self.tracking:
            # 卡尔曼预测
            prediction = self.kf.predict()
            pred_x = int(prediction[0])
            pred_y = int(prediction[1])

            # 安全边界检查
            h, w = working_frame.shape[:2]
            # search_margin = 100
            # x1 = max(0, pred_x - search_margin)
            # y1 = max(0, pred_y - search_margin)
            # x2 = min(w, pred_x + search_margin)
            # y2 = min(h, pred_y + search_margin)

            try:
                # 执行跟踪
                success, bbox = self.tracker.update(working_frame)
                if success:
                    x, y, width, height = map(int, bbox)

                    # 有效性检查
                    if width <= 0 or height <= 0 or x >= w or y >= h:
                        success = False
                    else:
                        # 更新卡尔曼滤波器
                        center_x = x + width // 2
                        center_y = y + height // 2
                        if 0 <= center_x < w and 0 <= center_y < h:
                            self.kf.correct((center_x, center_y))

                        # 绘制跟踪框和预测点
                        cv2.rectangle(working_frame, (x, y), (x+width, y+height), (0, 255, 0), 2)
                        # cv2.circle(working_frame, (pred_x, pred_y), 5, (0, 0, 255), -1)
                        # 新增 '+' 字形标记
                        line_length = 10
                        # cv2.line(working_frame, (pred_x - line_length, pred_y), (pred_x + line_length, pred_y), (0, 255, 0), 2)
                        # cv2.line(working_frame, (pred_x, pred_y - line_length), (pred_x, pred_y + line_length), (0, 255, 0), 2)
                        self.failure_count = 0
                        cv2.circle(working_frame, (pred_x, pred_y), 3, (0, 0, 255), -1)
                        # 左上角坐标(x,y) 右下角坐标(x1,y1)
                        detection = [x, y, width, height]
            except Exception as e:
                print(f"跟踪异常：{e}")
                success = False

            if not success:
                self.failure_count += 1
                if self.failure_count > self.max_failure:
                    # 尝试特征匹配恢复
                    recovered_bbox = self.match_features(working_frame)
                    if recovered_bbox is not None:
                        rx, ry, rw, rh = recovered_bbox
                        if 10 < rw < w and 10 < rh < h:
                            # 重新初始化跟踪器
                            self.tracker = cv2.TrackerCSRT_create()
                            self.tracker.init(working_frame, (rx, ry, rw, rh))
                            self.kf = KalmanFilter(rx + rw//2, ry + rh//2)
                            self.failure_count = 0
                            cv2.putText(working_frame, "Recovered by Features", (20, 100),
                                       cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 0, 255), 2)
                    else:
                        self.tracking = False
                        self.message_cb(False, "目标已丢失")
                        cv2.putText(working_frame, "Tracking Lost", (20, 80),
                                   cv2.FONT_HERSHEY_SIMPLEX, 0.75, (0, 0, 255), 2)
                else:
                    # 继续使用卡尔曼预测
                    x = int(pred_x - 50)
                    y = int(pred_y - 50)
                    w = h = 100
                    cv2.rectangle(working_frame, (x, y), (x + w, y + h), (255, 0, 0), 2)
                    cv2.putText(working_frame, f"Predicting... ({self.failure_count})", (20, 80),
                               cv2.FONT_HERSHEY_SIMPLEX, 0.75, (255, 255, 0), 2)
                    self.message_cb(False, "目标丢失，正在预测")
                    detection = [x, y, w, h]

        return working_frame, detection, success

    def show_frame(self, frame):
        processed_frame, det = self.process_frame(frame)
        print(det)
        cv2.imshow("Smart Tracker", processed_frame)
        key = cv2.waitKey(1)
        if key == 27:  # ESC键退出
            cv2.destroyAllWindows()


def message_cb(status, message):
    print(f"status: {status} {message}")

# 使用示例
if __name__ == "__main__":
    cap = cv2.VideoCapture(0)
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)

    tracker = SmartTracker(message_cb)
    center_x, center_y, width, height = 320, 240, 100, 100  # 示例中心点和宽高

    while True:
        ret, frame = cap.read()
        if not ret:
            break


        if not tracker.tracking:
            tracker.start_tracking(frame, center_x, center_y, width, height)

        tracker.show_frame(frame)

    cap.release()